from django.urls import path
from . import views
from .views import pelushi_dolls_view, add_to_cart, cart_detail, remove_from_cart

urlpatterns = [
    path('', views.product_list, name='product_list'),
    path('<int:product_id>/', views.product_detail, name='product_detail'),
    
    path('pelushi-dolls/',pelushi_dolls_view, name='pelushi_dolls'),
    path('baftani-dolls/', views.baftani_dolls, name='baftani_dolls'),
    path('se-d-dolls/', views.se_d_dolls, name='se_d_dolls'),
    path('custom-dolls/', views.custom_dolls, name='custom_dolls'),
    path('doll-clothes/', views.doll_clothes, name='doll_clothes'),
    # سایر URL های موجود
    path('add-to-cart/<int:product_id>/', add_to_cart, name='add_to_cart'),
    path('cart/', views.cart_detail, name='cart_detail'),
    path('remove-from-cart/<int:cart_item_id>/', remove_from_cart, name='remove_from_cart'),
    #path('<str:category>/', views.product_list, name='product_list'),
    path('update_cart_item/<int:item_id>/', views.update_cart_item, name='update_cart_item'),
    path('checkout/', views.checkout, name='checkout'),
    path('payment_success/', views.payment_success, name='payment_success'),

    path('<str:category>/<int:product_id>/', views.product_detail, name='product_detail'),
    
    
    path('<str:category>/', views.product_list, name='product_list'),
    
    path('custom_doll/', views.custom_doll, name='custom_doll'),  # مسیر جدید برای ساخت عروسک

]
