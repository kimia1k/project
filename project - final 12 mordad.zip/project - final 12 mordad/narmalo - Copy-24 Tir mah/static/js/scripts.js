document.getElementById('cartIcon').addEventListener('click', function () {
    window.location.href = '/products/cart/';
});


document.addEventListener('DOMContentLoaded', function () {
    console.log('JavaScript is working!');
    let slideIndex = 0;
    const slides = document.querySelectorAll('.slide');
    const dots = document.querySelectorAll('.dot');
    const totalSlides = slides.length;

    // نمونه کدی برای نمایش یک پیغام خوشامدگویی
    const welcomeMessage = document.querySelector('.welcome-message');
    if (welcomeMessage) {
        welcomeMessage.textContent = 'به سایت ما خوش آمدید!';
    }

    // افزودن نمونه‌ای از عملکرد دکمه
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(function (button) {
        button.addEventListener('click', function () {
            alert('دکمه کلیک شد!');
        });
    });

    // مدیریت فرم تماس
    const contactForm = document.querySelector('#contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function (event) {
            event.preventDefault();
            alert('پیام شما ارسال شد!');
            contactForm.reset();
        });
    }

    // مدیریت اسلایدر
    let currentSlide = 0;

    function updateSlider() {
        const slider = document.querySelector('.product-wrapper');
        if (slider) {
            const slideWidth = slider.querySelector('.product-item').clientWidth + 20;
            slider.style.transform = `translateX(-${currentSlide * slideWidth}px)`;
        }
    }

    window.slideProducts = function (direction) {
        const slider = document.querySelector('.product-wrapper');
        if (slider) {
            const totalSlides = slider.querySelectorAll('.product-item').length;
            const slidesToShow = 3;

            currentSlide += direction;
            if (currentSlide < 0) {
                currentSlide = 0;
            } else if (currentSlide > totalSlides - slidesToShow) {
                currentSlide = totalSlides - slidesToShow;
            }

            updateSlider();
        }
    };

    updateSlider();

    // مدیریت سبد خرید
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    const cartCountElement = document.getElementById('cartCount');
    const cartItemsElement = document.getElementById('cartItems');
    const emptyCartMessage = document.getElementById('emptyCartMessage');

    function updateCartDisplay() {
        if (cartCountElement) {
            cartCountElement.textContent = cartItems.length;
            cartCountElement.style.display = cartItems.length > 0 ? 'inline-block' : 'none';
        }
        if (cartItemsElement && emptyCartMessage) {
            cartItemsElement.innerHTML = '';
            if (cartItems.length === 0) {
                emptyCartMessage.style.display = 'block';
            } else {
                emptyCartMessage.style.display = 'none';
                cartItems.forEach((item, index) => {
                    const listItem = document.createElement('li');
                    listItem.textContent = item;
                    cartItemsElement.appendChild(listItem);
                });
            }
        }
    }

    function addToCart(item) {
        cartItems.push(item);
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
        updateCartDisplay();
    }

    window.addToCart = addToCart;
    updateCartDisplay();

    // مدیریت جستجو

    const searchIcon = document.getElementById('searchIcon');
    const searchBox = document.getElementById('searchForm');
    const searchInput = document.getElementById('searchInput');

    searchIcon.addEventListener('click', function () {
        if (searchBox.style.display === 'none' || searchBox.style.display === '') {
            searchBox.style.display = 'block';
            searchInput.focus();
        } else {
            searchBox.style.display = 'none';
        }
    });

    // بستن باکس جستجو وقتی کاربر روی جای دیگری کلیک می‌کند
    document.addEventListener('click', function (event) {
        if (!searchBox.contains(event.target) && !searchIcon.contains(event.target)) {
            searchForm.style.display = 'none';
        }
    });




    function showSlide(index) {
        if (index >= totalSlides) {
            slideIndex = 0;
        } else if (index < 0) {
            slideIndex = totalSlides - 1;
        } else {
            slideIndex = index;
        }
        const slider = document.querySelector('.slider');
        slider.style.transform = 'translateX(' + (-slideIndex * 100) + '%)';
        updateDots();
    }

    function updateDots() {
        dots.forEach((dot, index) => {
            dot.classList.toggle('active', index === slideIndex);
        });
    }

    function nextSlide() {
        showSlide(slideIndex + 1);
    }

    function currentSlide(index) {
        showSlide(index);
    }

    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => currentSlide(index));
    });

    setInterval(nextSlide, 5000); // تغییر اسلاید هر 5 ثانیه

    // نمایش اولین اسلاید و فعال کردن اولین دایره
    showSlide(slideIndex);



    const addToCartButtons = document.querySelectorAll('.btn-add-to-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function (event) {
            event.preventDefault();
            const url = this.href;

            fetch(url, {
                method: 'GET',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
                .then(response => response.json())
                .then(data => {
                    const cartCountElement = document.querySelector('.cart-count');
                    if (cartCountElement) {
                        cartCountElement.textContent = data.total_items;
                    } else {
                        const cartContainer = document.querySelector('.cart-container');
                        const span = document.createElement('span');
                        span.classList.add('cart-count');
                        span.textContent = data.total_items;
                        cartContainer.appendChild(span);
                    }
                });
        });
    });

});