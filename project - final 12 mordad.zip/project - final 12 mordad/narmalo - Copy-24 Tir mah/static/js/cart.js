function updateCartCount(totalItems) {
    const cartCountElement = document.querySelector('.cart-count');
    if (cartCountElement) {
        cartCountElement.textContent = totalItems;
    } else {
        const cartIconContainer = document.querySelector('.cart-icon-container');
        const newCartCountElement = document.createElement('span');
        newCartCountElement.classList.add('cart-count');
        newCartCountElement.textContent = totalItems;
        cartIconContainer.appendChild(newCartCountElement);
    }
}
