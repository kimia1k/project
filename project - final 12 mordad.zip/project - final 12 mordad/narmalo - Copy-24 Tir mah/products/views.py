from django.shortcuts import render, get_object_or_404, redirect
from .models import Product, Cart, CartItem
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse

def pelushi_dolls_view(request):
    products = Product.objects.filter(category='pelushi_dolls')
    return render(request, 'products/pelushi_dolls.html', {'products': products})

def product_list(request):
    products = Product.objects.all()
    return render(request, 'products/product_list.html', {'products': products})

def product_detail(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    return render(request, 'products/product_detail.html', {'product': product})

def baftani_dolls(request):
    products = Product.objects.filter(category='baftani_dolls')
    return render(request, 'products/baftani_dolls.html', {'products': products})

def se_d_dolls(request):
    products = Product.objects.filter(category='se_d_dolls')
    return render(request, 'products/se_d_dolls.html', {'products': products})


def custom_dolls(request):
    return render(request, 'products/custom_dolls.html')

def doll_clothes(request):
    products = Product.objects.filter(category='doll_clothes')
    return render(request, 'products/doll_clothes.html', {'products': products})
    


@login_required
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    cart, created = Cart.objects.get_or_create(user=request.user, defaults={'user': request.user})
    cart_item, created = CartItem.objects.get_or_create(cart=cart, product=product, defaults={'cart': cart, 'product': product})
    if not created:
        cart_item.quantity += 1
    cart_item.save()
    
    cart_items = CartItem.objects.filter(cart=cart)
    total_items = sum(item.quantity for item in cart_items)

    
    #if request.is_ajax():
       # return JsonResponse({'total_items': total_items})
    return redirect('cart_detail')

@login_required
@login_required
def cart_detail(request):
    cart, created = Cart.objects.get_or_create(user=request.user)
    cart_items = CartItem.objects.filter(cart=cart)
    
    # محاسبه جمع کل تعداد محصولات
    total_items = sum(item.quantity for item in cart_items)
    
    # محاسبه جمع کل قیمت‌ها
    total_price = sum(item.product.price * item.quantity for item in cart_items)
    
    return render(request, 'products/cart_detail.html', {
        'cart_items': cart_items,
        'total_items': total_items,
        'total_price': total_price
    })
    
@login_required
def remove_from_cart(request, cart_item_id):
    cart_item = get_object_or_404(CartItem, id=cart_item_id, cart__user=request.user)
    cart_item.delete()
    return redirect('cart_detail')


@login_required
def update_cart_item(request, item_id):
    cart_item = get_object_or_404(CartItem, id=item_id, cart__user=request.user)
    
    if request.method == 'POST':
        action = request.POST.get('action')
        
        if action == 'increase':
            cart_item.quantity += 1
            cart_item.save()
        elif action == 'decrease':
            if cart_item.quantity > 1:
                cart_item.quantity -= 1
                cart_item.save()
            else:
                cart_item.delete()  # حذف محصول در صورت صفر شدن تعداد
        elif action == 'remove':
            cart_item.delete()

    return redirect('cart_detail')


@login_required
def checkout(request):
    cart, created = Cart.objects.get_or_create(user=request.user)
    cart_items = CartItem.objects.filter(cart=cart)
    
    # محاسبه جمع کل قیمت‌ها
    total_price = sum(item.product.price * item.quantity for item in cart_items)
    
    if request.method == 'POST':
        # اینجا میتوانید منطق پرداخت را پیاده‌سازی کنید
        # به عنوان مثال، اگر پرداخت موفق بود، سبد خرید را خالی کنید
        cart_items.delete()
        return redirect('payment_success')

    return render(request, 'products/checkout.html', {
        'cart_items': cart_items,
        'total_price': total_price
    })

@login_required
def payment_success(request):
    return render(request, 'products/payment_success.html')


def product_list(request):
    products = Product.objects.all()
    return render(request, 'products/product_list.html', {'products': products})


# def product_list(request, category):
#     templates = {
#         'pelushi-dolls': 'products/pelushi_dolls.html',
#         'baftani-dolls': 'products/baftani_dolls.html',
#         'se-d-dolls': 'products/se_d_dolls.html',
#         'custom-dolls': 'products/custom_dolls.html',
#         'doll-clothes': 'products/doll_clothes.html',
#     }
#     template = templates.get(category, 'products/home.html')
#     products = Product.objects.filter(category=category)
#     return render(request, 'products/product_list.html', {'products': products})
#     #return render(request, template, {'products': products})

def product_detail(request, category, product_id):
    product = get_object_or_404(Product, id=product_id, category=category)
    return render(request, 'products/doll_detail.html', {'product': product})


def custom_doll(request):
    return render(request, 'products/custom_doll.html')