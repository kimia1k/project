document.addEventListener('DOMContentLoaded', function () {
    const canvas = document.getElementById('dollCanvas');
    const colorPicker = document.getElementById('colorPicker');
    const partSelector = document.getElementById('partSelector');
    const confirmBtn = document.getElementById('confirmBtn');
    const resetBtn = document.getElementById('resetBtn');
    const dollOptions = document.querySelectorAll('.doll-option');
    const modal = document.getElementById('dollModal');
    const closeModal = document.getElementsByClassName('close')[0];
    const modalDollImage = document.getElementById('modalDollImage');
    const dollImage = document.getElementById('dollImage');

    // ایجاد صحنه
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, canvas.clientWidth / canvas.clientHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ canvas: canvas });
    renderer.setSize(canvas.clientWidth, canvas.clientHeight);

    // ایجاد نورپردازی
    const light = new THREE.DirectionalLight(0xffffff, 1);
    light.position.set(1, 1, 1).normalize();
    scene.add(light);

    // بارگذاری مدل سه‌بعدی
    const loader = new THREE.GLTFLoader();
    let doll;

    dollOptions.forEach(option => {
        option.addEventListener('click', function () {
            const src = this.src;
            modalDollImage.src = src;
            modal.style.display = "block";
            canvas.style.display = "none";
        });
    });

    // به‌روزرسانی رنگ بخش عروسک
    colorPicker.addEventListener('input', function () {
        if (doll) {
            const selectedPart = partSelector.value;
            doll.traverse(function (child) {
                if (child.isMesh && child.name.includes(selectedPart)) {
                    child.material.color.set(colorPicker.value);
                }
            });
        }
    });

    // انیمیشن صحنه
    function animate() {
        requestAnimationFrame(animate);
        if (doll) {
            doll.rotation.y += 0.01;
        }
        renderer.render(scene, camera);
    }

    // دکمه‌ها
    confirmBtn.addEventListener('click', function () {
        alert('عروسک شما تایید شد!');
    });

    resetBtn.addEventListener('click', function () {
        colorPicker.value = '#ff0000';
        if (doll) {
            doll.traverse(function (child) {
                if (child.isMesh) {
                    child.material.color.set(colorPicker.value);
                }
            });
        }
    });

    // بستن مودال
    closeModal.addEventListener('click', function () {
        modal.style.display = "none";
    });

    window.addEventListener('click', function (event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    });
});
